// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.1.1
// LVGL VERSION: 8.3.3
// PROJECT: esp32

#include "ui.h"
#include "ui_helpers.h"

///////////////////// VARIABLES ////////////////////
lv_obj_t * ui_Screen1;
lv_obj_t * ui_Screen1_Panel1;
lv_obj_t * ui_socbar;
lv_obj_t * ui_TEMERATURE;
lv_obj_t * ui_CURRENT;
lv_obj_t * ui_RANGE;
lv_obj_t * ui_VOLTAGE;
lv_obj_t * ui_SPEED;
lv_obj_t * ui_VOLTAGE1;
lv_obj_t * ui_inputsoc;
lv_obj_t * ui_inputvoltage;
lv_obj_t * ui_inputange;
lv_obj_t * ui_inputtemperature;
lv_obj_t * ui_inputcurrent;

///////////////////// TEST LVGL SETTINGS ////////////////////
#if LV_COLOR_DEPTH != 16
    #error "LV_COLOR_DEPTH should be 16bit to match SquareLine Studio's settings"
#endif
#if LV_COLOR_16_SWAP !=0
    #error "LV_COLOR_16_SWAP should be 0 to match SquareLine Studio's settings"
#endif

///////////////////// ANIMATIONS ////////////////////

///////////////////// FUNCTIONS ////////////////////

///////////////////// SCREENS ////////////////////
void ui_Screen1_screen_init(void)
{
    ui_Screen1 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen1, LV_OBJ_FLAG_SCROLLABLE);      /// Flags

    ui_Screen1_Panel1 = lv_obj_create(ui_Screen1);
    lv_obj_set_width(ui_Screen1_Panel1, lv_pct(100));
    lv_obj_set_height(ui_Screen1_Panel1, lv_pct(100));
    lv_obj_set_align(ui_Screen1_Panel1, LV_ALIGN_CENTER);
    lv_obj_clear_flag(ui_Screen1_Panel1, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_Screen1_Panel1, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_Screen1_Panel1, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen1_Panel1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Screen1_Panel1, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_socbar = lv_bar_create(ui_Screen1_Panel1);
    lv_bar_set_value(ui_socbar, 25, LV_ANIM_OFF);
    lv_obj_set_width(ui_socbar, 150);
    lv_obj_set_height(ui_socbar, 9);
    lv_obj_set_x(ui_socbar, -1);
    lv_obj_set_y(ui_socbar, 2);
    lv_obj_set_align(ui_socbar, LV_ALIGN_TOP_RIGHT);
    lv_obj_set_style_bg_color(ui_socbar, lv_color_hex(0x232423), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_socbar, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    lv_obj_set_style_radius(ui_socbar, 0, LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_socbar, lv_color_hex(0x00EF3A), LV_PART_INDICATOR | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_socbar, 255, LV_PART_INDICATOR | LV_STATE_DEFAULT);

    ui_TEMERATURE = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_TEMERATURE, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_TEMERATURE, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_TEMERATURE, 20);
    lv_obj_set_y(ui_TEMERATURE, 73);
    lv_label_set_text(ui_TEMERATURE, "TEMPERATURE :");

    ui_CURRENT = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_CURRENT, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_CURRENT, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_CURRENT, 20);
    lv_obj_set_y(ui_CURRENT, 55);
    lv_label_set_text(ui_CURRENT, "CURRENT :");

    ui_RANGE = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_RANGE, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_RANGE, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_RANGE, 20);
    lv_obj_set_y(ui_RANGE, 91);
    lv_label_set_text(ui_RANGE, "RANGE :");

    ui_VOLTAGE = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_VOLTAGE, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_VOLTAGE, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_VOLTAGE, 20);
    lv_obj_set_y(ui_VOLTAGE, 36);
    lv_label_set_text(ui_VOLTAGE, "VOLTAGE :");

    ui_SPEED = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_SPEED, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_SPEED, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_align(ui_SPEED, LV_ALIGN_CENTER);
    lv_label_set_text(ui_SPEED, "50");
    lv_obj_set_style_text_font(ui_SPEED, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_VOLTAGE1 = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_VOLTAGE1, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_VOLTAGE1, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_VOLTAGE1, 20);
    lv_obj_set_y(ui_VOLTAGE1, 18);
    lv_label_set_text(ui_VOLTAGE1, "SOC :");

    ui_inputsoc = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_inputsoc, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_inputsoc, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_inputsoc, 63);
    lv_obj_set_y(ui_inputsoc, 18);
    lv_label_set_text(ui_inputsoc, "98%");

    ui_inputvoltage = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_inputvoltage, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_inputvoltage, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_inputvoltage, 95);
    lv_obj_set_y(ui_inputvoltage, 36);
    lv_label_set_text(ui_inputvoltage, "400");

    ui_inputange = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_inputange, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_inputange, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_inputange, 81);
    lv_obj_set_y(ui_inputange, 91);
    lv_label_set_text(ui_inputange, "98");

    ui_inputtemperature = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_inputtemperature, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_inputtemperature, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_inputtemperature, 138);
    lv_obj_set_y(ui_inputtemperature, 73);
    lv_label_set_text(ui_inputtemperature, "33");

    ui_inputcurrent = lv_label_create(ui_Screen1);
    lv_obj_set_width(ui_inputcurrent, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_inputcurrent, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_inputcurrent, 98);
    lv_obj_set_y(ui_inputcurrent, 55);
    lv_label_set_text(ui_inputcurrent, "0.6");

}

void ui_init(void)
{
    lv_disp_t * dispp = lv_disp_get_default();
    lv_theme_t * theme = lv_theme_default_init(dispp, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED),
                                               true, LV_FONT_DEFAULT);
    lv_disp_set_theme(dispp, theme);
    ui_Screen1_screen_init();
    lv_disp_load_scr(ui_Screen1);
}
