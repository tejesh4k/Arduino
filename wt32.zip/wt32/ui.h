// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.1.1
// LVGL VERSION: 8.3.3
// PROJECT: esp32

#ifndef _ESP32_UI_H
#define _ESP32_UI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

extern lv_obj_t * ui_Screen1;
extern lv_obj_t * ui_Screen1_Panel1;
extern lv_obj_t * ui_socbar;
extern lv_obj_t * ui_TEMERATURE;
extern lv_obj_t * ui_CURRENT;
extern lv_obj_t * ui_RANGE;
extern lv_obj_t * ui_VOLTAGE;
extern lv_obj_t * ui_SPEED;
extern lv_obj_t * ui_VOLTAGE1;
extern lv_obj_t * ui_inputsoc;
extern lv_obj_t * ui_inputvoltage;
extern lv_obj_t * ui_inputange;
extern lv_obj_t * ui_inputtemperature;
extern lv_obj_t * ui_inputcurrent;






void ui_init(void);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
